const fs = require("fs/promises");
const deleteFile = async (path) => {
  await fs.rm(`./public/${path}`, { force: true });
};

module.exports = deleteFile;
