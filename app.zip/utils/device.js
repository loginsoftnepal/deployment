const getDeviceName = (userAgent) => {
  var deviceCategory;

  if (userAgent.includes("Mobile")) {
    deviceCategory = "mobile";
  } else if (userAgent.includes("Tablet")) {
    deviceCategory = "tablet";
  } else if (
    userAgent.includes("Windows") ||
    userAgent.includes("Macintosh") ||
    userAgent.includes("Linux")
  ) {
    deviceCategory = "desktop";
  } else {
    deviceCategory = "others";
  }
  return deviceCategory;
};

module.exports = getDeviceName;
