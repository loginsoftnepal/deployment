exports.generateSlugFromString = (input) => {
  return input.toLowerCase().replaceAll(" ", "-").replace(/\//g, "-");
};
