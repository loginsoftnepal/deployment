const { authUser } = require("../utils/auth");
const requireUserRole = require("./requireUserRole");
const restrictTo = require("./restrictTo");

const requireAdmin = [authUser, requireUserRole, restrictTo("admin")];

module.exports = requireAdmin;
