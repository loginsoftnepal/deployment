const { db } = require("../utils/db");

const requireUserRole = async (req, res, next) => {
  if (!req["userId"]) {
    return res.status(401).json({ message: "Not authorized!" });
  }

  let query = `SELECT * FROM users WHERE id = '${req["userId"]}'`;

  db.query(query, async (error, result) => {
    if (error || result.length == 0) {
      return res.status(401).json({ message: "Not authorized!" });
    }
    req.userRole = result?.[0].role;
    next();
  });
};

module.exports = requireUserRole;
