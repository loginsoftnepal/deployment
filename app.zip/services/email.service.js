const sendEmail = require("../utils/sendEmail");

function generateVerificationCode() {
  return Math.floor(Math.random() * 900000) + 100000;
}

exports.sendEmailVerification = async (email) => {
  const verificationCode = generateVerificationCode();

  // Generate the verification link
  // const verificationLink = `https://yourwebsite.com/verify?code=${verificationCode}`;
      // <!--<p><a href="${verificationLink}">${verificationLink}</a></p>-->

  const emailBody = `
      <h1>Email Verification</h1>
      <p>Thank you for signing up. Please use the following verification code to verify your email:</p>
      <p>Verification code: <h3>${verificationCode}</h3></p>
    `;

  const options = {
    subject: "Verify Your Email | Expert Business",
    html: emailBody,
    email: email,
    // text: link,
  };

  await sendEmail(options);
  return verificationCode;
};
