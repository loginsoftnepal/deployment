const express = require("express");
const router = express.Router();

const { uploadImage } = require("../utils/multer");
const requireAdmin = require("../middlewares/requireAdmin");
const {
  getComposedReplies,
  deleteEmailCompose,
  createEmailCompose,
} = require("../modules/emailCompose");

router.get("/", requireAdmin, getComposedReplies);

router.post("/", requireAdmin, uploadImage, createEmailCompose);
router.delete("/:id", requireAdmin, deleteEmailCompose);
// router.patch("/:id", requireAdmin, uploadImage, updateComposedEmailReply);

module.exports = router;
