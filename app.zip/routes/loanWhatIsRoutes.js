const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { createLoanWhatIs, updateLoanWhatIs, getLoanWhatIs, deleteLoanWHatIs, getSingleLoanWhatIs } = require('../modules/loanWhatIs');







router.put('/' ,uploadImage ,updateLoanWhatIs)
router.get('/' ,getLoanWhatIs)
router.get('/:loanType' ,getSingleLoanWhatIs)

router.post('/', uploadImage ,createLoanWhatIs)
router.delete('/', deleteLoanWHatIs)






module.exports = router;