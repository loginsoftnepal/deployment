const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");

const { uploadImage } = require("../utils/multer");
const {
  updateFooterContact,
  getFooterContact,
  createFooterContact,
} = require("../modules/footerContact");

router.patch("/", updateFooterContact);
router.get("/", getFooterContact);
router.post("/", createFooterContact);
// router.delete('/',authUser, deleteFooterLinks)

module.exports = router;
