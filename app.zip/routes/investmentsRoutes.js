const express = require("express");
const router = express.Router();

const { uploadImage } = require("../utils/multer");

const requireAdmin = require("../middlewares/requireAdmin");
const {
  getInvestments,
  getPublishedInvestments,
  getInvestmentBySlug,
  createInvestment,
  updateInvestment,
  deleteInvestment,
} = require("../modules/services/investments");

router.get("/", getInvestments);
router.get("/all", getPublishedInvestments);
router.get("/get/:slug", getInvestmentBySlug);

router.post("/", requireAdmin, uploadImage, createInvestment);
router.patch("/:id", requireAdmin, uploadImage, updateInvestment);
router.delete("/:id", requireAdmin, deleteInvestment);

module.exports = router;
