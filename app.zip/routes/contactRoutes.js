const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");

const {
  updateContact,
  getContact,
  deletContact,
  createContact,
} = require("../modules/contact");
const requireAdmin = require("../middlewares/requireAdmin");

router.patch("/", updateContact);
router.get("/", getContact);
router.post("/", createContact);
router.delete("/", requireAdmin, deletContact);

module.exports = router;
