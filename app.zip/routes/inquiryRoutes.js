const express = require("express");
const router = express.Router();

const { uploadInquiryDocument } = require("../utils/inquiryStorage");
const { authUser } = require("../utils/auth");
const {
  createInquiry,
  getUserInquries,
  deleteInquiry,
} = require("../modules/inquiry");
const requireAdmin = require("../middlewares/requireAdmin");

router.post("/new", authUser, uploadInquiryDocument, createInquiry);

router.get("/all", requireAdmin, getUserInquries);

router.delete("/:id", requireAdmin, deleteInquiry);

module.exports = router;
