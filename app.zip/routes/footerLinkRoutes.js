const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");

const { uploadImage } = require("../utils/multer");
const {
  deleteFooterLinks,
  createFooterLinks,
  getFooterLinks,
  updateFooterLinks,
} = require("../modules/footerLinks");

router.patch("/", updateFooterLinks);
router.get("/", getFooterLinks);
router.post("/", createFooterLinks);
router.delete("/", deleteFooterLinks);

module.exports = router;
