const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { createLoanEligibility, getLoanEligibility, updateLoanEligibility, deleteLoanEligibility } = require('../modules/loanEligibility');







router.put('/' ,updateLoanEligibility)
router.get('/' ,getLoanEligibility)
router.post('/', createLoanEligibility)
router.delete('/', deleteLoanEligibility)






module.exports = router;