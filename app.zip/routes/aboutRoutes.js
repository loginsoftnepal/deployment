const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");

const { uploadImage } = require("../utils/multer");
const {
  updateTeam,
  getTeam,
  createTeam,
  deleteTeam,
} = require("../modules/team");
const {
  createAbout,
  getAbout,
  updateAboutImage,
  updateAboutText,
  deleteAboutImage,
} = require("../modules/about");

router.put("/image", uploadImage, updateAboutImage);
router.patch("/text", updateAboutText);

router.get("/", getAbout);
router.post("/", uploadImage, createAbout);
// router.delete('/',authUser, deleteTeam)
router.delete("/image/:image", authUser, deleteAboutImage);

module.exports = router;
