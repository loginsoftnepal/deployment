const express = require("express");
const router = express.Router();

const { uploadImage } = require("../utils/multer");
const {
  updateServiceCategory,
  getServiceCategory,
  createServiceCategory,
  deleteServiceCategory,
  getServiceCategoryBySlug,
  getServiceCategoryById,
  getPublishedServiceCategories,
  deleteServiceCategoryImage,
} = require("../modules/services/serviceCategory");
const requireAdmin = require("../middlewares/requireAdmin");

router.get("/", getServiceCategory);
router.get("/all", getPublishedServiceCategories);
router.get("/:id", getServiceCategoryById);
router.get("/slug/:slug", getServiceCategoryBySlug);

router.post("/", requireAdmin, uploadImage, createServiceCategory);
router.patch("/:id", requireAdmin, uploadImage, updateServiceCategory);
router.delete("/:id", requireAdmin, deleteServiceCategory);
router.delete("/:id/:image", requireAdmin, deleteServiceCategoryImage);

module.exports = router;
