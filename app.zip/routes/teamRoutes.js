const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");

const { uploadImage } = require("../utils/multer");
const {
  updateTeam,
  getTeam,
  createTeam,
  deleteTeam,
  updateTeamMemberImage,
  deleteTeamMemberImage,
} = require("../modules/team");
const requireAdmin = require("../middlewares/requireAdmin");

router.get("/", getTeam);
router.put("/:id/image", requireAdmin, uploadImage, updateTeamMemberImage);
router.patch("/:id", requireAdmin, updateTeam);
router.post("/", requireAdmin, uploadImage, createTeam);
router.delete("/:id", requireAdmin, deleteTeam);
router.delete("/:id/:image", requireAdmin, deleteTeamMemberImage);

module.exports = router;
