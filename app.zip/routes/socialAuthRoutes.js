const express = require("express");
const router = express.Router();

const { loginWithFacebook, loginWithGoogle } = require("../modules/socialAuth");

router.post("/facebook", loginWithFacebook);
router.post("/google", loginWithGoogle);

module.exports = router;
