const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { updateFundRaiser, getFundRaiser, createFundRaiser, deleteFundRaiser } = require('../modules/fundRaiser');







router.put('/' ,uploadImage ,updateFundRaiser)
router.get('/' ,getFundRaiser)
router.post('/', uploadImage ,createFundRaiser)
router.delete('/', deleteFundRaiser)






module.exports = router;