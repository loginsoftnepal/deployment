const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { updateLandingHero, getLandingHero, createLandingHero } = require('../modules/landingHero');







router.patch('/', updateLandingHero)
router.get('/' ,getLandingHero)
router.post('/', authUser ,createLandingHero)
// router.delete('/',authUser, deleteProduct)






module.exports = router;