const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { updateLandingTestimonial, getLandingTestimonial, createLandingTestimonial } = require('../modules/landingTestimonial');







router.put('/', authUser ,updateLandingTestimonial)
router.get('/' ,getLandingTestimonial)
router.post('/', authUser ,createLandingTestimonial)
// router.delete('/',authUser, deleteProduct)






module.exports = router;