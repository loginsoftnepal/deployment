const express = require("express");
const { authUser } = require("../utils/auth");
const { getUsers } = require("../modules/users");
const requireAdmin = require("../middlewares/requireAdmin");

const router = express.Router();

// router.patch("/", updateContact);
router.get("/", requireAdmin, getUsers);
// router.post("/", createContact);
// router.delete("/", deletContact);

module.exports = router;
