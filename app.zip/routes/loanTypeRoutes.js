const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");

const { uploadImage } = require("../utils/multer");
const {
  updateLoanType,
  getLoanType,
  createLoanType,
  deleteLoanType,
} = require("../modules/loanType");

router.put("/", updateLoanType);
router.get("/", getLoanType);
router.post("/", createLoanType);
router.delete("/", deleteLoanType);

module.exports = router;
