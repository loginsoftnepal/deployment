const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { updateProduct, getProducts, createProduct, deleteProduct } = require('../modules/product');







router.put('/' ,uploadImage ,updateProduct)
router.get('/' ,getProducts)
router.post('/' , uploadImage ,createProduct)
router.delete('/', deleteProduct)






module.exports = router;