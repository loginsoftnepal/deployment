const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");

const { uploadImage } = require("../utils/multer");
const {
  updateLandingAbout,
  getLandingAbout,
  createLandingAbout,
  updateLandingAboutImage,
  updateLandingAboutText,
  deleteLandingAboutImage,
} = require("../modules/landingAbout");

router.put("/image", uploadImage, updateLandingAboutImage);
router.patch("/text", updateLandingAboutText);

router.get("/", getLandingAbout);
router.post("/", authUser, uploadImage, createLandingAbout);
// router.delete('/',authUser, deleteProduct)
router.delete("/image/:image", authUser, deleteLandingAboutImage);

module.exports = router;
