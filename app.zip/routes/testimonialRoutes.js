const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { updateTestimonial, getTestimonioal, createTestimonial, deleteTestimonial } = require('../modules/testimonial');







router.patch('/:id' ,updateTestimonial)
router.get('/' ,getTestimonioal)
router.post('/' ,createTestimonial)
router.delete('/:id', deleteTestimonial)






module.exports = router;