const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");

const { uploadImage } = require("../utils/multer");
const {
  updateFooterAbout,
  getFooterAbout,
  createFooterAbout,
} = require("../modules/footerAbout");
const requireAdmin = require("../middlewares/requireAdmin");

router.patch("/", requireAdmin, uploadImage, updateFooterAbout);
router.get("/", getFooterAbout);
router.post("/", requireAdmin, uploadImage, createFooterAbout);
// router.delete('/',authUser, deleteProduct)

module.exports = router;
