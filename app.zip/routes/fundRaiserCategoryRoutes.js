const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { updateFundRaiserCategory, getFundRaiserCategory, createFundRaiserCategory, deleteFundRaiserCategory } = require('../modules/fundRaiserCategory');







router.put('/' ,uploadImage ,updateFundRaiserCategory)
router.get('/' ,getFundRaiserCategory)
router.post('/', uploadImage ,createFundRaiserCategory)
router.delete('/', deleteFundRaiserCategory)






module.exports = router;