const express = require("express");
const router = express.Router();

const { uploadImage } = require("../utils/multer");
const {
  updateService,
  getServices,
  createService,
  deleteService,
  getServicesByCategorySlug,
  getSingleService
} = require("../modules/services/service");
const requireAdmin = require("../middlewares/requireAdmin");

router.get("/", getServices);
router.get("/get/:slug", getServicesByCategorySlug);
router.get("/:id", getSingleService);

router.post("/", requireAdmin, uploadImage, createService);
router.patch("/:id", requireAdmin, uploadImage, updateService);
router.delete("/:id", requireAdmin, deleteService);

module.exports = router;
