const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const {  getProductHero, createProductHero, updateProductHeroImage, updateProductHeroText } = require('../modules/productHero');







router.put('/text' ,uploadImage ,updateProductHeroText)
router.put('/image' ,uploadImage ,updateProductHeroImage)

router.get('/' ,getProductHero)
router.post('/', uploadImage ,createProductHero)







module.exports = router;