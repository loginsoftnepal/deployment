const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { updateFactorsLoan, getFactorsLoan, createFactorsLoan, deleteFactorsLoan } = require('../modules/factorsLoan');







router.put('/' ,uploadImage ,updateFactorsLoan)
router.get('/' ,getFactorsLoan)
router.post('/', uploadImage ,createFactorsLoan)
router.delete('/', deleteFactorsLoan)






module.exports = router;