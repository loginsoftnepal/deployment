const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { updateLandingServiceHeading, getLandingServiceHeading, createLandingServiceHeading } = require('../modules/landingService');







router.patch('/',updateLandingServiceHeading)
router.get('/' ,getLandingServiceHeading)
router.post('/' ,createLandingServiceHeading)
// router.delete('/',authUser, deleteProduct)






module.exports = router;