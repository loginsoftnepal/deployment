const express = require('express')
const router = express.Router();
const {authUser} = require('../utils/auth');

const { uploadImage } = require('../utils/multer');
const { addImage, deleteImage, getImage } = require('../modules/imageUpload');







// router.put('/', authUser ,uploadImage ,addImage)
router.get('/' ,getImage)
router.post('/addImage', uploadImage ,addImage)
router.delete('/', deleteImage)






module.exports = router;