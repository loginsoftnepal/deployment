const express = require("express");
const router = express.Router();
const {
  register,
  verifyEmailUsingVerification,
  login,
  getMe,
  logout,
  forgotPassword,
  resetPassword,
  changePassword,
  changeEmail,
  changeUsername,
  adminLogin,
  updateProfilePicture,
  updateUserFullname,
} = require("../modules/auth");
const { authUser } = require("../utils/auth");
const { uploadImage } = require("../utils/multer");

router.post("/register", register);
router.post("/verifyEmail", verifyEmailUsingVerification);
router.post("/login", login);
router.post("/adminLogin", adminLogin);
router.get("/me", authUser, getMe);
router.get("/logout", logout);
router.post("/forgotPassword", forgotPassword);
router.post("/resetPassword", resetPassword);
router.post("/changePassword", authUser, changePassword);
router.post("/changeEmail", authUser, changeEmail);
router.post("/changeUsername", authUser, changeUsername);
router.post("/changeFullname", authUser, updateUserFullname);

router.post("/updateProfile", authUser, uploadImage, updateProfilePicture);

module.exports = router;
