const express = require("express");
const router = express.Router();
const { authUser } = require("../utils/auth");
const requireAdmin = require("../middlewares/requireAdmin");
const { deviceCountriesOverview, statsOverview } = require("../modules/dash");

router.get("/overview", requireAdmin, statsOverview);
router.get("/device-countries", requireAdmin, deviceCountriesOverview);

module.exports = router;
