const { db } = require("../utils/db");
const path = require("path");

exports.createLoanType = (req, res, next) => {
  const { name } = req.body;
  const route = name.toLowerCase().replaceAll(" ", "-");

  let sql = `INSERT INTO loan_type SET ?`;
  let data = { name: name.toLowerCase(), route: route};
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Loan Type created",
    }); 
  });
};
exports.updateLoanType = (req, res, next) => {
  const { name, id } = req.body;
  const route = name.toLowerCase().replaceAll(" ", "-");
  const sql = `UPDATE loan_type SET name = ?, route = ? WHERE id = ?`;

  db.query(sql, [name.toLowerCase(), route, id], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Loan Type updated",
    });
  });
};
exports.deleteLoanType = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM loan_type WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Loan Type deleted",
    });
  });
};
exports.getLoanType = (req, res, next) => {
  let sql = `SELECT * FROM loan_type`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Loan Type fetched",
      data: result,
      // data: result[0]
    });
  });
};
