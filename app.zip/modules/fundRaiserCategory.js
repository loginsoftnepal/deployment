const { db } = require("../utils/db");
const path = require("path");

exports.createFundRaiserCategory = (req, res, next) => {
  const { name } = req.body;
  const route = name.toLowerCase().replaceAll(" ", "-");

  let sql = `INSERT INTO fundraiser_category SET ?`;
  let data = { name: name, route: route };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Fund Raiser created",
    });
  });
};
exports.updateFundRaiserCategory = (req, res, next) => {
  const { name, id } = req.body;
  const route = name.toLowerCase().replaceAll(" ", "-");
  const sql = `UPDATE fundraiser_category SET name = ?, route = ? WHERE id = ?`;

  db.query(sql, [name, route, id], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Fund Raiser Category updated",
    });
  });
};
exports.deleteFundRaiserCategory = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM fundraiser_category WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Fund Raiser Category deleted",
    });
  });
};
exports.getFundRaiserCategory = (req, res, next) => {
  let sql = `SELECT * FROM fundraiser_category`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Fund Raiser Category fetched",
      data: result,
      // data: result[0]
    });
  });
};
