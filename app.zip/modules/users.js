const { db } = require("../utils/db");

exports.getUsers = (req, res, next) => {
  let sql = `SELECT name, email, phone, profile, role FROM users`;
  // pagination
  var page = parseInt(Number(req.query.page).toFixed()); // ensure page/limit is not 0
  var limit = parseInt(Number(req.query.limit).toFixed()) || 10;
  // use pagination if page exists in query
  if (page) {
    const skip = (page - 1) * limit;
    sql += ` LIMIT ${limit} OFFSET ${skip}`;
  }
  const queryCount = `SELECT COUNT(*) AS total_count FROM users`;

  db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    
    var info = {};
    if (page) info = { page, limit, total: result[1][0].total_count };

    return res.status(200).json({
      message: "Users fetched",
      items: page ? result[0] : result,
      ...(page ? { info } : {}),
    });
  });
};
