const { db } = require('../utils/db');
const path = require('path');





exports.createLoanEligibility = (req, res, next) => {
    const { point1, point2, point3, point4, point5, loanType } = req.body;
    let sql = `INSERT INTO loan_eligibility SET ?`
    let data = { point1: point1, point2: point2, point3: point3, point4: point4, point5: point5, loanType: loanType }
    db.query(sql, data, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: `${loanType} Eligibility created`,
        })
    })

}
exports.updateLoanEligibility = (req, res, next) => {
    const { point1, point2, point3, point4, point5, loanType, id } = req.body;
    const sql = `UPDATE loan_eligibility SET point1 = ?, point2 = ?, point3 = ?, point4 = ?, point5 = ? WHERE id = ?`;

    db.query(sql, [point1, point2, point3, point4, point5, loanType, id], (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: `${loanType} Eligibility updated`,
        })
    })
}
exports.deleteLoanEligibility = (req, res, next) => {
    const { id } = req.body;
    const sql = `DELETE FROM loan_eligibility WHERE id = '${id}'`;

    db.query(sql, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: `Loan Eligibility deleted`,
        })
    })

}
exports.getLoanEligibility = (req, res, next) => {
    let sql = `SELECT * FROM loan_eligibility`;
    db.query(sql, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Loan Eligibility fetched",
            data: result
            // data: result[0]
        })
    })
}


