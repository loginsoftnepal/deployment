const { db } = require("../utils/db");
const path = require("path");

exports.createLoanWhatIs = (req, res, next) => {
  const { title, detail, image, loanType } = req.body;
  let sql = `INSERT INTO loan_what_is SET ?`;
  let data = { title: title, detail: detail, image: image, loanType: loanType };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: `${loanType} What IS created`,
    });
  });
};
exports.updateLoanWhatIs = (req, res, next) => {
  const { title, detail, image, loanType, id } = req.body;
  const sql = `UPDATE loan_what_is SET title = ?,detail = ?,loanType = ?, image = ? WHERE id = ?`;

  db.query(sql, [title, detail, loanType, image, id], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: `${loanType} What IS updated`,
    });
  });
};
exports.deleteLoanWHatIs = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM loan_what_is WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: `Loan What IS deleted`,
    });
  });
};
exports.getLoanWhatIs = (req, res, next) => {
  let sql = `SELECT * FROM loan_what_is`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Loan What  Is fetched",
      data: result,
      // data: result[0]
    });
  });
};

exports.getSingleLoanWhatIs = (req, res, next) => {
  const {loanType} = req.params
  console.log(loanType)
  let sql = `SELECT * FROM loan_what_is where loanType = '${loanType}'`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Loan What  Is fetched",
      data: result[0],
      // data: result[0]
    });
  });
};

