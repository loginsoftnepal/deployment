const { db } = require('../utils/db');
const path = require('path');




exports.createLandingServiceHeading = (req, res, next) => {
    const { heading, blueSpan, detail } = req.body;
    let sql = `INSERT INTO landing_service_heading SET ?`
    let data = { heading: heading, blueSpan: blueSpan, detail: detail }
    db.query(sql, data, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(400).json({
                message: "Database operation failed",
            })
        }
        return res.status(201).json({
            message: "Landing service heading created",
        })
    })

}

exports.updateLandingServiceHeading = (req, res, next) => {

    const { heading, blueSpan, detail } = req.body;
    const sql = `UPDATE landing_service_heading SET heading = ?,blueSpan = ?,detail = ?`;

    db.query(sql, [heading, blueSpan, detail], (error, result) => {
        if (error) {
            console.log(error)
            return res.status(400).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Landing service heading updated",
        })
    })
}

exports.getLandingServiceHeading = (req, res, next) => {
    let sql = `SELECT * FROM landing_service_heading`;
    db.query(sql, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Landing service heading fetched",
            data: result[0]
            // data: result[0]
        })
    })
}
