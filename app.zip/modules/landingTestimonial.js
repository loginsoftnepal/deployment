const { db } = require('../utils/db');
const path = require('path');


exports.createLandingTestimonial = (req, res, next) => {
    const { heading, subHeading } = req.body;
    let sql = `INSERT INTO landing_testimonial_heading SET ?`
    let data = { heading: heading, subHeading: subHeading }
    db.query(sql, data, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(201).json({
            message: "Landing page testimonial heading created",
        })
    })

}
exports.updateLandingTestimonial = (req, res, next) => {

    const { heading, subHeading} = req.body;
    const sql = `UPDATE landing_testimonial_heading SET heading = ?,subHeading = ?`;

    db.query(sql, [heading, subHeading], (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Landing page testimonial heading updated",
        })
    })
}

exports.getLandingTestimonial = (req, res, next) => {
    let sql = `SELECT * FROM landing_testimonial_heading`;
    db.query(sql, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Landing page testimonial heading fetched",
            data: result[0]
            // data: result[0]
        })
    })
}


