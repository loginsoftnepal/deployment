const { db } = require('../utils/db');
const path = require('path');



exports.createFooterContact = (req, res, next) => {
    const { email, phone1, phone2, address } = req.body;
    let sql = `INSERT INTO footer_contact SET ?`
    let data = { email: email, phone1: phone1, phone2: phone2, address: address }
    db.query(sql, data, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Footer contact created",
        })
    })

}


exports.updateFooterContact = (req, res, next) => {

    const { email, phone1, phone2, address } = req.body;

    const sql = `UPDATE footer_contact SET email = ?, phone1 = ?, phone2 = ?, address = ? `;

    db.query(sql, [email, phone1, phone2, address], (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Footer contact updated",
        })
    })
}

exports.getFooterContact = (req, res, next) => {
    let sql = `SELECT * FROM footer_contact`;
    db.query(sql, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Footer contact fetched",
            data: result[0]
            // data: result[0]
        })
    })
}




