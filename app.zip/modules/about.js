const { db } = require("../utils/db");
const path = require("path");
const deleteFile = require("../utils/file");

exports.createAbout = (req, res, next) => {
  const { heading, para1, para2, image } = req.body;
  let sql = `INSERT INTO about SET ?`;
  let data = { heading: heading, para1: para1, para2: para2, image: image };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "About updated",
    });
  });
};

exports.updateAboutImage = (req, res, next) => {
  const image = req.files?.[0]?.filename;
  const sql = `UPDATE about SET image = ?`;

  db.query(sql, [image], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "About Image updated",
    });
  });
};
exports.updateAboutText = (req, res, next) => {
  const { heading, para1, para2 } = req.body;
  const sql = `UPDATE about SET heading = ?,para1 = ?,para2 = ?`;

  db.query(sql, [heading, para1, para2], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "About Text updated",
    });
  });
};
exports.getAbout = (req, res, next) => {
  let sql = `SELECT * FROM about`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "About fetched",
      data: result[0],
      // data: result[0]
    });
  });
};

exports.deleteAboutImage = async (req, res, next) => {
  const { image } = req.params;
  await deleteFile(image);

  let sql = `UPDATE about SET image = NULL`;

  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({ message: "Database operation failed" });
    }
    res.end();
  });
};
