const { db } = require("../utils/db");
const path = require("path");

exports.createFactorsLoan = (req, res, next) => {
  const { title, detail, loanType, image } = req.body;
  let sql = `INSERT INTO factors_loan SET ?`;
  let data = { title: title, detail: detail, image: image, loanType: loanType };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: `${loanType} factors created`,
    });
  });
};
exports.updateFactorsLoan = (req, res, next) => {
  const { title, detail, image, loanType, id } = req.body;
  const sql = `UPDATE factors_loan SET title = ?,detail = ?,loanType = ?, image = ? WHERE id = ?`;

  db.query(sql, [title, detail, loanType, image, id], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: `${loanType} factors updated`,
    });
  });
};
exports.deleteFactorsLoan = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM factors_loan WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: `Loan factors deleted`,
    });
  });
};
exports.getFactorsLoan = (req, res, next) => {
  let sql = `SELECT * FROM factors_loan`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "factors loan fetched",
      data: result,
      // data: result[0]
    });
  });
};
