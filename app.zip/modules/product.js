const { db } = require("../utils/db");
const path = require("path");

exports.createProduct = (req, res, next) => {
  const { name, detail, image, link, rank } = req.body;
  let sql = `INSERT INTO our_product SET ?`;
  let data = {
    name: name,
    detail: detail,
    link: link,
    image: image,
    rank: rank,
  };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(201).json({
      message: "Product created",
    });
  });
};
exports.updateProduct = (req, res, next) => {
  const { name, detail, image, link, rank, id } = req.body;
  const sql = `UPDATE our_product SET name = ?,detail = ?,link = ?, image = ?, rank = ? WHERE id = ?`;

  db.query(sql, [name, detail, link, image, rank, id], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Product updated",
    });
  });
};
exports.deleteProduct = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM our_product WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Product deleted",
    });
  });
};
exports.getProducts = (req, res, next) => {
  let sql = `SELECT * FROM our_product`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Products fetched",
      data: result,
      // data: result[0]
    });
  });
};
