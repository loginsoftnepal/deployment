const { db } = require("../utils/db");
const path = require("path");

exports.addImage = (req, res, next) => {
  const image = req.files[0].filename;
  let sql = `INSERT INTO image_upload SET ?`;
  let data = { image: image };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Image added",
    });
  });
};

exports.deleteImage = (req, res, next) => {
  console.log("called");
  const { id } = req.body;
  const sql = `DELETE FROM image_upload WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Image deleted",
    });
  });
};

exports.getImage = (req, res, next) => {
  let sql = `SELECT * FROM image_upload`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Images fetched",
      data: result,
      // data: result[0]
    });
  });
};
