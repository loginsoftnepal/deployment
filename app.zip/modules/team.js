const { db } = require("../utils/db");
const deleteFile = require("../utils/file");

exports.createTeam = (req, res, next) => {
  const image = req.files?.[0]?.filename;
  const { name, role, rank, type } = req.body;
  let sql = `INSERT INTO team SET ?`;
  let data = { name: name, role: role, rank: rank, type: type, image: image };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Team member created",
    });
  });
};
exports.updateTeam = (req, res, next) => {
  const { id } = req.params;
  const type = "Admin";
  const { name, role, rank } = req.body;
  const sql = `UPDATE team SET name = ?,role = ?,rank = ?, type = ? WHERE id = ?`;

  db.query(sql, [name, role, rank, type, id], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Team member updated",
    });
  });
};

exports.updateTeamMemberImage = (req, res, next) => {
  const { id } = req.params;
  const image = req.files?.[0]?.filename;

  const sql = `UPDATE team SET image = ? WHERE id = ?`;

  db.query(sql, [image, id], (error, result) => {
    if (error) {
      return res.status(400).json({
        message: "Database operation failed",
      });
    }
    res.end();
  });
};

exports.getTeam = (req, res, next) => {
  let sql = `SELECT * FROM team`;

  // pagination
  var page = parseInt(Number(req.query?.page).toFixed()); // ensure page/limit is not 0
  var limit = parseInt(Number(req.query?.limit).toFixed()) || 10;
  // use pagination if page exists in query
  if (page) {
    const skip = (page - 1) * limit;
    sql += ` LIMIT ${limit} OFFSET ${skip}`;
  }
  const queryCount = `SELECT COUNT(*) AS total_count FROM team`;

  db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
    if (error) {
      return res.status(400).json({
        message: "Database operation failed",
      });
    }

    const info = { page, limit, total: result?.[1]?.[0]?.total_count };

    return res.status(200).json({
      message: "Team members fetched",
      items: page ? result?.[0] : result,
      ...(page ? { info } : {}),
    });
  });
};

exports.deleteTeamMemberImage = async (req, res, next) => {
  const { id, image } = req.params;
  await deleteFile(image);

  let sql = `UPDATE team SET image = NULL WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({ message: "Database operation failed" });
    }
    res.end();
  });
};

exports.deleteTeam = (req, res, next) => {
  const { id } = req.params;

  const fetchSql = `SELECT image FROM team WHERE id = '${id}'`;

  db.query(fetchSql, async (error, result) => {
    if (error) {
      return res.status(403).json({ message: "Database operation failed" });
    }
    if (result?.[0]?.image) await deleteFile(result?.[0]?.image);

    const sql = `DELETE FROM team WHERE id = '${id}'`;

    db.query(sql, (error, result) => {
      if (error) {
        console.log(error);
        return res.status(401).json({
          message: "Database operation failed",
        });
      }
      return res.status(200).json({
        message: "Team member deleted",
      });
    });
  });
};
