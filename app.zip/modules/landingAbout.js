const { db } = require("../utils/db");
const path = require("path");
const deleteFile = require("../utils/file");

exports.createLandingAbout = (req, res, next) => {
  const image = req.files[0].filename;
  const { heading, blueSpan, detail } = req.body;
  let sql = `INSERT INTO landing_about SET ?`;
  let data = {
    heading: heading,
    blueSpan: blueSpan,
    detail: detail,
    image: image,
  };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(400).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Landing page About created",
    });
  });
};

exports.updateLandingAboutText = (req, res, next) => {
  const { heading, blueSpan, detail } = req.body;
  const sql = `UPDATE landing_about SET heading = ?,blueSpan = ?,detail = ?`;

  db.query(sql, [heading, blueSpan, detail], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(400).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Landing page About Text updated",
    });
  });
};

exports.updateLandingAboutImage = (req, res, next) => {
  const image = req.files[0].filename;

  const sql = `UPDATE landing_about SET image = ?`;

  db.query(sql, [image], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(400).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Landing page About Image updated",
    });
  });
};

exports.getLandingAbout = (req, res, next) => {
  let sql = `SELECT * FROM landing_about`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(400).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Landing About  fetched",
      data: result[0],
      // data: result[0]
    });
  });
};

exports.deleteLandingAboutImage = async (req, res, next) => {
  const { image } = req.params;
  await deleteFile(image);

  let sql = `UPDATE landing_about SET image = NULL`;

  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({ message: "Database operation failed" });
    }
    res.end();
  });
};
