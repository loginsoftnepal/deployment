const { db } = require("../utils/db");
const path = require("path");

exports.createFooterLinks = (req, res, next) => {
  const { facebook, twitter, insta, linkedIn, youtube } = req.body;
  let sql = `INSERT INTO footer_link SET ?`;
  let data = {
    facebook: facebook,
    twitter: twitter,
    insta: insta,
    linkedIn: linkedIn,
    youtube: youtube,
  };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Footer links created",
    });
  });
};

exports.updateFooterLinks = (req, res, next) => {
  const { facebook, twitter, insta, linkedIn, youtube } = req.body;

  const sql = `UPDATE footer_link SET facebook = ?,twitter = ?, insta = ?, linkedIn = ?, youtube = ?`;

  db.query(
    sql,
    [facebook, twitter, insta, linkedIn, youtube],
    (error, result) => {
      if (error) {
        console.log(error);
        return res.status(401).json({
          message: "Database operation failed",
        });
      }
      return res.status(200).json({
        message: "Footer links updated",
      });
    }
  );
};

exports.getFooterLinks = (req, res, next) => {
  let sql = `SELECT * FROM footer_link`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Footer links fetched",
      data: result[0],
      // data: result[0]
    });
  });
};

exports.deleteFooterLinks = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM footer_link WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Footer Link deleted",
    });
  });
};
