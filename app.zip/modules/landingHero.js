const { db } = require('../utils/db');
const path = require('path');


exports.createLandingHero = (req, res, next) => {
    const { heading, subHeading } = req.body;
    let sql = `INSERT INTO landing_hero SET ?`
    let data = { heading: heading, subHeading: subHeading }
    db.query(sql, data, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(400).json({
                message: "Database operation failed",
            })
        }
        return res.status(201).json({
            message: "Landing page Hero created",
        })
    })

}
exports.updateLandingHero = (req, res, next) => {

    const { heading, subHeading } = req.body;
    const sql = `UPDATE landing_hero SET heading = ?,subHeading = ?`;

    db.query(sql, [heading, subHeading], (error, result) => {
        if (error) {
            console.log(error)
            return res.status(400).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Landing page Hero heading updated",
        })
    })
}

exports.getLandingHero = (req, res, next) => {
    let sql = `SELECT * FROM landing_hero`;
    db.query(sql, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Landing page hero fetched",
            data: result[0]
            // data: result[0]
        })
    })
}


