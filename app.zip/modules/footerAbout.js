const { db } = require('../utils/db');
const path = require('path');



exports.createFooterAbout = (req, res, next) => {
    const { about, blueSpan } = req.body;
    let sql = `INSERT INTO footer_about SET ?`
    let data = { about: about, blueSpan: blueSpan}
    db.query(sql, data, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Footer About created",
        })
    })

}


exports.updateFooterAbout = (req, res, next) => {

    const { about, blueSpan } = req.body;
   
    const sql = `UPDATE footer_about SET about = ?,blueSpan = ?`;

    db.query(sql, [about, blueSpan], (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Footer About updated",
        })
    })
}

exports.getFooterAbout = (req, res, next) => {
    let sql = `SELECT * FROM footer_about`;
    db.query(sql, (error, result) => {
        if (error) {
            console.log(error)
            return res.status(401).json({
                message: "Database operation failed",
            })
        }
        return res.status(200).json({
            message: "Footer About fetched",
            data: result[0]
            // data: result[0]
        })
    })
}




