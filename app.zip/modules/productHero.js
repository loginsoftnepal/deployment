const { db } = require("../utils/db");
const path = require("path");

exports.createProductHero = (req, res, next) => {
  const { heading, blueSpan, detail, image } = req.body;
  let sql = `INSERT INTO product_hero SET ?`;
  let data = {
    heading: heading,
    blueSpan: blueSpan,
    detail: detail,
    image: image,
  };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(201).json({
      message: "Produce hero created",
    });
  });
};

exports.updateProductHeroText = (req, res, next) => {
  const { heading, blueSpan, detail } = req.body;
  const sql = `UPDATE product_hero SET heading = ?,blueSpan = ?,detail = ?`;

  db.query(sql, [heading, blueSpan, detail], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Produce hero Text updated",
    });
  });
};

exports.updateProductHeroImage = (req, res, next) => {
  const { image } = req.body;
  const sql = `UPDATE product_hero SET image = ?`;

  db.query(sql, [image], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Produce hero Image updated",
    });
  });
};

exports.getProductHero = (req, res, next) => {
  let sql = `SELECT * FROM product_hero`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Product hero fetched",
      data: result[0],
      // data: result[0]
    });
  });
};
