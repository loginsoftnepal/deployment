const { db } = require("../utils/db");

exports.statsOverview = async (req, res, next) => {
  const serviceCatQuery = `SELECT COUNT(*) AS serviceCatCount FROM service_categories WHERE isPublished = 1`;
  const servicesQuery = `SELECT COUNT(*) AS servicesCount FROM services WHERE isPublished = 1`;
  const inquiriesQuery = `SELECT COUNT(*) AS inquiriesCount FROM user_inquiries`;
  const inquiriesThisWeekQuery = `SELECT COUNT(*) AS inquiriesWeekCount FROM user_inquiries WHERE YEARWEEK(created_at) = YEARWEEK(CURDATE())`;

  db.query(
    `${serviceCatQuery}; ${servicesQuery}; ${inquiriesQuery}; ${inquiriesThisWeekQuery}`,
    async (error, result) => {
      if (error) {
        return res.status(401).json({
          message: "Failed to fetch stats data",
        });
      }

      var stas = {
        serviceCats: result[0][0].serviceCatCount,
        services: result[1][0].servicesCount,
        inquiries: result[2][0].inquiriesCount,
        inquiriesThisWeek: result[3][0].inquiriesWeekCount,
      };
      res.send(stas);
    }
  );
};

exports.deviceCountriesOverview = async (req, res, next) => {
  const countrySQL = `SELECT countryCode AS _id, COUNT(*) AS total FROM users GROUP BY countryCode`;

  db.query(countrySQL, async (error, countryRes) => {
    if (error) {
      return res.status(401).json({
        message: "Failed to fetch countries data",
      });
    }

    // fetch by devices
    const devicesSQL = `SELECT device  AS _id, COUNT(*) AS total FROM users GROUP BY device`;
    db.query(devicesSQL, async (error, deviceRes) => {
      if (error) {
        return res.status(401).json({
          message: "Failed to fetch devices data",
        });
      }

      const countries = countryRes;
      const devices = deviceRes;

      res.send({
        countries,
        devices,
      });
    });
  });
};
