//

const { db } = require("../utils/db");

exports.createInquiry = (req, res, next) => {
  const {
    // subject,
    name,
    email,
    address,
    phone,
    message,
    type,
    ref_id,
    service,
  } = req.body;

  if (!name || !email || !type || !ref_id) {
    return res.status(401).json({ message: "Invalid inquiry input!" });
  }

  // const documents = req.files[0] ? ["inquiries/" + req.files[0]?.filename] : "";

  const query =
    "INSERT INTO user_inquiries (name, email, address, phone, message, type, ref_id, service) VALUES (?,?,?,?,?,?,?,?)";

  db.query(
    query,
    [
      // subject,
      name,
      email,
      address,
      phone,
      message,
      type,
      ref_id,
      // documents,
      service,
      req.userId,
    ],
    (err, results) => {
      if (err) {
        return res.status(401).json({ message: "Inquiry creation failed" });
      }

      res.end();
    }
  );
};

exports.getUserInquries = (req, res, next) => {
  // let sql = `SELECT user_inquiries.*, users.email FROM user_inquiries JOIN users ON user_inquiries.user_id = users.id`;
  let sql = `SELECT * FROM user_inquiries`;

  // pagination
  var page = parseInt(Number(req.query?.page).toFixed()); // ensure page/limit is not 0
  var limit = parseInt(Number(req.query?.limit).toFixed()) || 10;

  // use pagination if page exists in query
  if (page) {
    const skip = (page - 1) * limit;
    sql += ` LIMIT ${limit} OFFSET ${skip}`;
  }
  const queryCount = `SELECT COUNT(*) AS total_count FROM user_inquiries`;

  db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
    if (error) {
      return res.status(403).json({ message: "Database operation failed" });
    }

    const info = { page, limit, total: result?.[1]?.[0]?.total_count };

    return res.status(200).json({
      message: "User inquiries fetched",
      items: page ? result?.[0] : result,
      ...(page ? { info } : {}),
    });
  });
};

exports.deleteInquiry = (req, res, next) => {
  const { id } = req.params;
  const sql = `DELETE FROM user_inquiries WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    res.end();
  });
};
