const { db } = require("../utils/db");
const path = require("path");

exports.createContact = (req, res, next) => {
  const { name, address, phone, email, message, subject } = req.body;
  let sql = `INSERT INTO contact SET ?`;
  let data = {
    name: name,
    address: address,
    phone: phone,
    email: email,
    message: message,
    subject: subject,
    status: "un-checked",
  };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({ message: "Database operation failed" });
    }
    return res.status(200).json({
      message: "Contact created",
    });
  });
};
exports.updateContact = (req, res, next) => {
  const { seen } = req.body;
  const sql = `UPDATE contact SET seen = ? id = ?`;

  db.query(sql, [seen, id], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "COntact updated to seen",
    });
  });
};
exports.deletContact = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM contact WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Contact deleted",
    });
  });
};

exports.getContact = (req, res, next) => {
  let sql = `SELECT * FROM contact`;

  // pagination
  var page = parseInt(Number(req.query.page).toFixed()); // ensure page/limit is not 0
  var limit = parseInt(Number(req.query.limit).toFixed()) || 10;

  // use pagination if page exists in query
  if (page) {
    const skip = (page - 1) * limit;
    sql += ` LIMIT ${limit} OFFSET ${skip}`;
  }

  const queryCount = `SELECT COUNT(*) AS total_count FROM contact`;

  db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }

    
    var info = {};
    if (page) info = { page, limit, total: result[1][0].total_count };

    return res.status(200).json({
      message: "Contacts fetched",
      items: page ? result[0] : result,
      ...(page ? { info } : {}),
    });
  });
};
