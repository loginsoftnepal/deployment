const { db } = require("../utils/db");

exports.createTestimonial = (req, res, next) => {
  const { name, role, detail, rank } = req.body;
  let sql = `INSERT INTO testimonial SET ?`;
  let data = { name: name, role: role, rank: rank, detail: detail };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Testimonial created",
    });
  });
};
exports.updateTestimonial = (req, res, next) => {
  const { id } = req.params;
  const { name, role, detail, rank } = req.body;
  const sql = `UPDATE testimonial SET name = ?,role = ?,rank = ?, detail = ? WHERE id = ?`;

  db.query(sql, [name, role, rank, detail, id], (error, result) => {
    if (error) {
      console.log(error);
      return res.status(400).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Testimonial updated",
    });
  });
};
exports.deleteTestimonial = (req, res, next) => {
  const { id } = req.params;
  const sql = `DELETE FROM testimonial WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(400).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Testimonial deleted",
    });
  });
};
exports.getTestimonioal = (req, res, next) => {
  let sql = `SELECT * FROM testimonial`;

  // pagination
  var page = parseInt(Number(req.query.page).toFixed()); // ensure page/limit is not 0
  var limit = parseInt(Number(req.query.limit).toFixed()) || 10;
  // use pagination if page exists in query
  if (page) {
    const skip = (page - 1) * limit;
    sql += ` LIMIT ${limit} OFFSET ${skip}`;
  }
  const queryCount = `SELECT COUNT(*) AS total_count FROM testimonial`;

  db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
    if (error) {
      return res.status(400).json({
        message: "Database operation failed",
      });
    }

    var info = {};
    if (page) info = { page, limit, total: result[1][0].total_count };

    return res.status(200).json({
      message: "Testimonials fetched",
      items: page ? result[0] : result,
      ...(page ? { info } : {}),
    });
  });
};
