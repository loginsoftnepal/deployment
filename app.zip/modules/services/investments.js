const { db } = require("../../utils/db");
const deleteFile = require("../../utils/file");
const { generateSlugFromString } = require("../../utils/slug");

exports.createInvestment = (req, res, next) => {
  const image = req.files?.[0]?.filename;

  let query = `INSERT INTO investments SET`;

  const updates = [];
  Object.keys(req.body).map((i) => {
    if (i === "isPublished") {
      updates.push(`${i} = "${req.body[i] ? 1 : 0}"`);
    } else if (i === "description") {
      updates.push(`${i} = "${req.body[i].replace(/"/g, '\\"')}"`);
    } else updates.push(`${i} = "${req.body[i]}"`);

    // update slug if title present
    if (i == "title") {
      updates.push(`slug = "${generateSlugFromString(req.body.title || "")}"`);
    }
  });
  if (image) updates.push(`image = "${image}"`);

  query += ` ${updates.join(", ")}`;

  db.query(query, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Failed to create investment",
      });
    }
    res.end();
  });
};

exports.updateInvestment = (req, res, next) => {
  const { id } = req.params;

  const image = req.files?.[0]?.filename;

  // Start building the SQL query
  let query = "UPDATE investments SET";
  const updates = [];
  Object.keys(req.body).map((i) => {
    if (i === "isPublished") {
      updates.push(`${i} = "${req.body[i] ? 1 : 0}"`);
    } else updates.push(`${i} = "${req.body[i]}"`);

    // update slug if title present
    if (i == "title") {
      updates.push(`slug = "${generateSlugFromString(req.body.title || "")}"`);
    }
  });

  if (image) updates.push(`image = "${image}"`);

  query += ` ${updates.join(", ")}`;
  query += ` WHERE id = ${id}`;

  db.query(query, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Investment update failed",
      });
    }
    res.end();
  });
};
exports.deleteInvestment = (req, res, next) => {
  const { id } = req.params;

  const fetchSql = `SELECT image FROM investments WHERE id = '${id}'`;

  db.query(fetchSql, async (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    if (result?.[0]?.image) await deleteFile(result?.[0]?.image);

    const sql = `DELETE FROM investments WHERE id = '${id}'`;

    db.query(sql, (error, result) => {
      if (error) {
        return res.status(403).json({ message: "Failed to delete" });
      }
      res.end();
    });
  });
};

exports.getInvestments = (req, res, next) => {
  let sql = `SELECT * FROM investments`;
  // pagination
  var page = parseInt(Number(req.query?.page).toFixed()); // ensure page/limit is not 0
  var limit = parseInt(Number(req.query?.limit).toFixed()) || 10;
  // use pagination if page exists in query
  if (page) {
    const skip = (page - 1) * limit;
    sql += ` LIMIT ${limit} OFFSET ${skip}`;
  }
  const queryCount = `SELECT COUNT(*) AS total_count FROM investments`;

  db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
    if (error) {
      return res.status(403).json({ message: "Database operation failed" });
    }
    const info = { page, limit, total: result?.[1]?.[0]?.total_count };

    return res.status(200).json({
      message: "Investments fetched",
      items: page ? result?.[0] : result,
      ...(page ? { info } : {}),
    });
  });
};

// get published category
exports.getPublishedInvestments = (req, res, next) => {
  let sql = `SELECT title, slug, image FROM investments`;
  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Investments fetched",
      items: result,
    });
  });
};

exports.getInvestmentBySlug = (req, res, next) => {
  const { slug } = req.params;
  let sql = `SELECT * FROM investments where slug = '${slug}'`;
  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Investment data fetched",
      data: result[0],
    });
  });
};
