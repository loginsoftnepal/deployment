const { db } = require("../utils/db");
const path = require("path");

exports.createService = (req, res, next) => {
  const {
    title,
    category,
    loanType,
    point1,
    point2,
    point3,
    point4,
    point5,
    price,
    para1,
    para2,
    rank,
    image,
    thumbnail,
  } = req.body;
  let sql = `INSERT INTO our_service SET ?`;
  let data = {
    title: title.toLowerCase(),
    loanType: loanType,
    category: category,
    point1: point1,
    point2: point2,
    point3: point3,
    point4: point4,
    point5: point5,
    thumbnail: thumbnail,
    price: price,
    para1: para1,
    para2: para2,
    image: image,
    rank: rank,
  };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service created",
    });
  });
};
exports.updateService = (req, res, next) => {
  const {
    title,
    category,
    loanType,
    point1,
    point2,
    point3,
    point4,
    point5,
    price,
    para1,
    para2,
    rank,
    id,
    image,
    thumbnail,
  } = req.body;
  const sql = `UPDATE our_service SET title = ?,category = ?, loanType = ?, point1 = ?,point2 = ?, point3 = ?, point4 = ?, point5 = ?, price = ?, para1 = ?, para2 = ?, rank = ?, image = ?, thumbnail = ? WHERE id = ?`;

  db.query(
    sql,
    [
      title.toLowerCase(),
      category,
      loanType,
      point1,
      point2,
      point3,
      point4,
      point5,
      price,
      para1,
      para2,
      rank,
      image,
      thumbnail,
      id,
    ],
    (error, result) => {
      if (error) {
        console.log(error);
        return res.status(401).json({
          message: "Database operation failed",
        });
      }
      return res.status(200).json({
        message: "Service updated",
      });
    }
  );
};
exports.deleteService = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM our_service WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service deleted",
    });
  });
};
exports.getServices = (req, res, next) => {
  let sql = `SELECT * FROM our_service`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Services fetched",
      data: result,
      // data: result[0]
    });
  });
};

exports.getSingleService = (req, res, next) => {
  const {id} = req.params
  let sql = `SELECT * FROM our_service where id = ${id}`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Services fetched",
      data: result[0],
      // data: result[0]
    });
  });
};

