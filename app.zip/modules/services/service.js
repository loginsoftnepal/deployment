const { db } = require("../../utils/db");
const path = require("path");

exports.createService = (req, res, next) => {
  let query = `INSERT INTO services SET`;

  const updates = [];
  Object.keys(req.body).map((i) => {
    if (i === "isPublished") {
      updates.push(`${i} = "${req.body[i] ? 1 : 0}"`);
    } else updates.push(`${i} = "${req.body[i]}"`);
  });

  query += ` ${updates.join(", ")}`;

  db.query(query, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service created",
    });
  });
};

exports.updateService = (req, res, next) => {
  const { id } = req.params;

  let query = "UPDATE services SET";
  const updates = [];
  Object.keys(req.body).map((i) => {
    if (i === "isPublished") {
      updates.push(`${i} = "${req.body[i] ? 1 : 0}"`);
    } else updates.push(`${i} = "${req.body[i]}"`);
  });
  query += ` ${updates.join(", ")}`;
  query += ` WHERE id = ${id}`;

  db.query(query, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service updated",
    });
  });
};
exports.deleteService = (req, res, next) => {
  const { id } = req.params;
  const sql = `DELETE FROM services WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service deleted",
    });
  });
};

exports.getServices = (req, res, next) => {
  const { serviceCategoryId } = req.query;
  if (!serviceCategoryId) {
    return res.status(403).json({
      message: "Invalid category request!",
    });
  }

  // check for category first exists or not
  let catSQL = `SELECT id  FROM service_categories where id = '${serviceCategoryId}' `;
  db.query(catSQL, (error, result) => {
    if (error || result.length === 0) {
      return res.status(403).json({ message: "Invalid category request!" });
    }

    let sql = `SELECT * FROM services where service_category = '${serviceCategoryId}'`;

    // pagination
    var page = parseInt(Number(req.query?.page).toFixed()); // ensure page/limit is not 0
    var limit = parseInt(Number(req.query?.limit).toFixed()) || 10;

    // use pagination if page exists in query
    if (page) {
      const skip = (page - 1) * limit;
      sql += ` LIMIT ${limit} OFFSET ${skip}`;
    }
    const queryCount = `SELECT COUNT(*) AS total_count FROM services WHERE service_category = ${serviceCategoryId}`;

    db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
      if (error) {
        return res.status(403).json({
          message: "Database operation failed",
        });
      }

      const info = { page, limit, total: result?.[1]?.[0]?.total_count };

      return res.status(200).json({
        message: "Services fetched",
        items: page ? result?.[0] : result,
        ...(page ? { info } : {}),
      });
    });
  });
};

exports.getSingleService = (req, res, next) => {
  const { id } = req.params;
  let sql = `SELECT * FROM services where id = ${id}`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Services fetched",
      data: result[0],
      // data: result[0]
    });
  });
};

// get service by slug
exports.getServicesByCategorySlug = (req, res, next) => {
  const { slug } = req.params;
  let sql = `SELECT id, title, slug, description, image FROM service_categories where slug = '${slug}' AND isPublished = 1`;
  db.query(sql, (error, result) => {
    if (error || result.length === 0) {
      return res.status(403).json({ message: "Invalid service request" });
    }

    let serviceQuery = `SELECT id, title, description, rank FROM services where service_category = ${result[0].id} AND isPublished = 1`;
    db.query(serviceQuery, (error, serviceResult) => {
      let services = [];
      if (!error && serviceResult.length > 0) {
        services = serviceResult;
      }
      return res.status(200).json({
        message: "Service fetched",
        data: { ...result[0], services },
      });
    });
  });
};
