const { db } = require("../../utils/db");
const path = require("path");
const { generateSlugFromString } = require("../../utils/slug");
const deleteFile = require("../../utils/file");

exports.createServiceCategory = (req, res, next) => {
  const image = req.files?.[0]?.filename;

  let query = `INSERT INTO service_categories SET`;

  const updates = [];
  Object.keys(req.body).map((i) => {
    if (i === "isPublished") {
      updates.push(`${i} = "${req.body[i] ? 1 : 0}"`);
    } else if (i === "description") {
      updates.push(`${i} = "${req.body[i].replace(/"/g, '\\"')}"`);
    } else updates.push(`${i} = "${req.body[i]}"`);

    // update slug if title present
    if (i == "title") {
      updates.push(`slug = "${generateSlugFromString(req.body.title || "")}"`);
    }
  });
  if (image) updates.push(`image = "${image}"`);

  query += ` ${updates.join(", ")}`;

  db.query(query, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category created",
    });
  });
};

exports.updateServiceCategory = (req, res, next) => {
  const { id } = req.params;

  const image = req.files?.[0]?.filename;

  // Start building the SQL query
  let query = "UPDATE service_categories SET";
  const updates = [];
  Object.keys(req.body).map((i) => {
    if (i === "isPublished") {
      updates.push(`${i} = "${req.body[i] ? 1 : 0}"`);
    } else updates.push(`${i} = "${req.body[i]}"`);

    // update slug if title present
    if (i == "title") {
      updates.push(`slug = "${generateSlugFromString(req.body.title || "")}"`);
    }
  });

  if (image) updates.push(`image = "${image}"`);

  query += ` ${updates.join(", ")}`;
  query += ` WHERE id = ${id}`;

  db.query(query, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category updated",
    });
  });
};
exports.deleteServiceCategory = (req, res, next) => {
  const { id } = req.params;

  // fetch service to delete image
  const fetchSql = `SELECT image FROM service_categories WHERE id = '${id}'`;

  db.query(fetchSql, async (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    if (result?.[0]?.image) await deleteFile(result?.[0]?.image);

    const sql = `DELETE FROM service_categories WHERE id = '${id}'`;

    db.query(sql, (error) => {
      if (error) {
        return res.status(403).json({
          message: "Database operation failed",
        });
      }
      return res.status(200).json({
        message: "Service Category deleted",
      });
    });
  });
};

// delete image from server & clear from db field
exports.deleteServiceCategoryImage = async (req, res, next) => {
  const { id, image } = req.params;
  await deleteFile(image);

  let sql = `UPDATE service_categories SET image = NULL WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({ message: "Database operation failed" });
    }
    res.end();
  });
};

exports.getServiceCategory = (req, res, next) => {
  let sql = `SELECT * FROM service_categories`;
  // pagination
  var page = parseInt(Number(req.query?.page).toFixed()); // ensure page/limit is not 0
  var limit = parseInt(Number(req.query?.limit).toFixed()) || 10;
  // use pagination if page exists in query
  if (page) {
    const skip = (page - 1) * limit;
    sql += ` LIMIT ${limit} OFFSET ${skip}`;
  }
  const queryCount = `SELECT COUNT(*) AS total_count FROM service_categories`;

  db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    const info = { page, limit, total: result?.[1]?.[0]?.total_count };

    return res.status(200).json({
      message: "Service Category fetched",
      items: page ? result?.[0] : result,
      ...(page ? { info } : {}),
    });
  });
};

// get published category
exports.getPublishedServiceCategories = (req, res, next) => {
  let sql = `SELECT title, slug, image FROM service_categories`;
  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Categories fetched",
      items: result,
    });
  });
};

exports.getServiceCategoryById = (req, res, next) => {
  const { id } = req.params;
  let sql = `SELECT * FROM service_categories where id = '${id}'`;
  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category fetched",
      data: result[0],
      // data: result[0]
    });
  });
};

exports.getServiceCategoryBySlug = (req, res, next) => {
  const { slug } = req.params;
  let sql = `SELECT * FROM service_categories where slug = '${slug}'`;
  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category fetched",
      data: result[0],
      // data: result[0]
    });
  });
};
