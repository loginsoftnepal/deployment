const { db } = require("../utils/db");
const path = require("path");

exports.createServiceCategory = (req, res, next) => {
  const { name, rank, image } = req.body;
  const route = name.toLowerCase().replaceAll(" ", "-");

  let sql = `INSERT INTO service_category SET ?`;
  let data = {
    name: name.toLowerCase(),
    route: route,
    image: image,
    rank: rank,
  };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category created",
    });
  });
};
exports.updateServiceCategory = (req, res, next) => {
  const { name, rank, id, image } = req.body;
  const route = name.toLowerCase().replaceAll(" ", "-");

  const sql = `UPDATE service_category SET name = ?, route = ?,image = ?, rank = ? WHERE id = ?`;

  db.query(
    sql,
    [name.toLowerCase(), route, image, rank, id],
    (error, result) => {
      if (error) {
        console.log(error);
        return res.status(401).json({
          message: "Database operation failed",
        });
      }
      return res.status(200).json({
        message: "Service Category updated",
      });
    }
  );
};
exports.deleteServiceCategory = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM service_category WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category deleted",
    });
  });
};
exports.getServiceCategory = (req, res, next) => {
  let sql = `SELECT * FROM service_category`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category fetched",
      data: result,
      // data: result[0]
    });
  });
};

exports.getSingleServiceCategory = (req, res, next) => {
  const { route } = req.params;
  console.log("dkjdjkd", route)
  let sql = `SELECT * FROM service_category where route = '${route}'`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category fetched",
      data: result[0],
      // data: result[0]
    });
  });
};
