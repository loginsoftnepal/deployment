const { db } = require("../utils/db");
const path = require("path");
const sendEmail = require("../utils/sendEmail");
const { decodeHTML } = require("../utils/html");

exports.createEmailCompose = (req, res, next) => {
  const attachment = req.files?.[0]?.filename;

  let query = `INSERT INTO compose_replies SET`;

  const updates = [];
  Object.keys(req.body).map((i) => updates.push(`${i} = "${req.body[i]}"`));
  if (attachment) updates.push(`attachment = "${attachment}"`);

  query += ` ${updates.join(", ")}`;

  db.query(query, async (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }

    const options = {
      subject: `${req.body?.subject} | Expert Business`,
      html: `${decodeHTML(req.body.message)} <br/><br/>
      ${
        attachment
          ? `
      <a href="${
        process.env.SERVER_URL + attachment
      }" target="_blank" style="display: inline-block; padding: 0.5rem 1rem; background-color: #f5f5f5; color: #333; text-decoration: none; border: 1px solid #ccc; border-radius: 4px;">View Attachment</a>
      `
          : ""
      }
      `,
      email: req.body.reply_to,
      // ...(attachment
      //   ? {
      //       attachments: [
      //         {
      //           filename: attachment,
      //           // path: `/public/${attachment}`, // Replace with the actual path to your file
      //           path: path.resolve(__dirname, "../public", attachment), // Replace with the actual path to your file
      //         },
      //       ],
      //     }
      //   : {}),
    };

    await sendEmail(options);

    return res.status(200).json({ message: "Email composed successfully!" });
  });
};

exports.deleteEmailCompose = (req, res, next) => {
  const { id } = req.params;
  const sql = `DELETE FROM compose_replies WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Service Category deleted",
    });
  });
};

exports.getComposedReplies = (req, res, next) => {
  let sql = `SELECT * FROM compose_replies`;
  // pagination
  var page = parseInt(Number(req.query?.page).toFixed()); // ensure page/limit is not 0
  var limit = parseInt(Number(req.query?.limit).toFixed()) || 10;
  // use pagination if page exists in query
  if (page) {
    const skip = (page - 1) * limit;
    sql += ` LIMIT ${limit} OFFSET ${skip}`;
  }
  const queryCount = `SELECT COUNT(*) AS total_count FROM compose_replies`;

  db.query(`${sql}; ${page ? queryCount : ""}`, (error, result) => {
    if (error) {
      return res.status(403).json({
        message: "Database operation failed",
      });
    }
    const info = { page, limit, total: result?.[1]?.[0]?.total_count };

    return res.status(200).json({
      message: "Composed Email Replies fetched",
      items: page ? result?.[0] : result,
      ...(page ? { info } : {}),
    });
  });
};
