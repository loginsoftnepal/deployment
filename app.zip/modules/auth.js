const bcrypt = require("bcryptjs");
const { db } = require("../utils/db");
const jwt = require("jsonwebtoken");
const sendEmail = require("../utils/sendEmail");
const emailService = require("../services/email.service");
const getDeviceName = require("../utils/device");

exports.register = async (req, res, next) => {
  const { name, email, password, username, role, phone, countryCode } =
    req.body;
  let sql = "INSERT INTO users SET ?";
  const salt = await bcrypt.genSaltSync(10);
  const hash = await bcrypt.hashSync(password, salt);

  // user device type;
  const device = getDeviceName(req.headers["user-agent"]);

  let data = {
    // username: username,
    name: name,
    email: email,
    password: hash,
    // role: role,
    role: "user",
    phone: phone,
    device,
    countryCode,
  };

  db.query(sql, data, async (error, result) => {
    if (error) {
      console.log(error);
      //   throw error;
      return res.status(401).json({
        message: "Failed to create new account!",
      });
    }

    // send email verification
    const verificationCode = await emailService.sendEmailVerification(email);
    // update verification code
    const verificationQuery =
      "UPDATE users SET verificationCode = ? WHERE email = ?";

    db.query(verificationQuery, [verificationCode, email], (error, result) => {
      if (error) {
        return res.status(401).json({
          message: "Failed to send email verification!",
        });
      }

      res.send({ message: "New user created" });
    });
  });
};

exports.verifyEmailUsingVerification = async (req, res, next) => {
  const { verificationCode, email, login } = req.body;
  let sql = "SELECT * FROM users WHERE email = ?";

  db.query(sql, [email], async (error, result) => {
    if (result.length == 0) {
      return res.status(401).json({ message: "Invalid verification attempt!" });
    }

    const codeMatched = result[0].verificationCode === verificationCode;

    if (!codeMatched) {
      return res.status(401).json({ message: "Invalid verification code!" });
    }

    // clear verification code & mark email verified
    const updateQuery =
      "UPDATE users SET verificationCode = NULL, emailVerified = 1 WHERE email = ?";

    db.query(updateQuery, [email], (error, results) => {
      if (error) {
        return res.status(401).json({ message: "Email verification failed!" });
      }

      // return with login token/data
      if (login) {
        const id = result[0].id;
        const token = jwt.sign({ id }, process.env.JWT_SECRET, {
          expiresIn: 21600,
        });

        const user = { ...result[0] };
        delete user.password;
        delete user.verificationCode;
        return res.json({ message: "The user is found", user, token: token });
      }

      res.json({ verified: 1 });
    });
  });
};

// admin only login controller
exports.adminLogin = async (req, res, next) => {
  const { password, email } = req.body;
  let sql = "SELECT * FROM users WHERE email = ? AND role = 'admin'";

  db.query(sql, [email], async (error, result) => {
    if (error || result.length == 0) {
      return res.status(401).json({
        message: "The email or password do not match",
        user: null,
        token: null,
      });
    }

    const checkPassword = await bcrypt.compare(password, result[0].password);
    if (!checkPassword) {
      return res.status(401).json({
        message: "The email or password do not match",
        user: null,
        token: null,
      });
    }

    const id = result[0].id;
    const token = jwt.sign({ id }, process.env.JWT_SECRET, {
      expiresIn: 21600,
    });
    const user = { ...result[0] };
    delete user.password;
    delete user.verificationCode;
    return res.json({ message: "The user is found", user, token: token });
  });
};

exports.login = async (req, res, next) => {
  const { password, email } = req.body;
  let sql = "SELECT * FROM users WHERE email = ?";

  db.query(sql, [email], async (error, result) => {
    if (result.length == 0) {
      return res.status(401).json({
        message: "The email or password do not match",
        user: null,
        token: null,
      });
    }
    const checkPassword = await bcrypt.compare(password, result[0].password);
    if (!checkPassword) {
      return res.status(401).json({
        message: "The email or password do not match",
        user: null,
        token: null,
      });
    }

    // check for email verified or not and send verification if not verified
    if (result[0].emailVerified === 0) {
      // sent email verification her
      const verificationCode = await emailService.sendEmailVerification(email);
      // update verification code
      const verificationQuery =
        "UPDATE users SET verificationCode = ? WHERE email = ?";

      db.query(
        verificationQuery,
        [verificationCode, email],
        (error, result) => {
          if (error) {
            return res.status(401).json({
              message: "Failed to send email verification!",
            });
          }

          return res.json({ message: "Email not verified", verifyEmail: true });
        }
      );
      return;
    }

    const id = result[0].id;
    const token = jwt.sign({ id }, process.env.JWT_SECRET, {
      expiresIn: 21600,
    });
    // const cookieOption = {
    //     expires: new Date(
    //         Date.now() + process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 * 1000
    //     ),
    //     httpOnly: true
    // }
    // res.cookie('jwt', token, cookieOption)
    const user = { ...result[0] };
    delete user.password;
    delete user.verificationCode;
    return res.json({ message: "Login Successfull", user, token: token });
  });
};

exports.changePassword = (req, res, next) => {
  const { oldPassword, newPassword } = req.body;
  const { userId } = req;
  let sql = "SELECT * FROM users WHERE id = ?";

  db.query(sql, [userId], async (error, result) => {
    if (result.length == 0) {
      return res.status(401).json({
        message: "The user is not found",
      });
    }
    const checkPassword = await bcrypt.compare(oldPassword, result[0].password);
    if (!checkPassword || !result) {
      return res.status(401).json({
        message: "The password did not match",
      });
    } else {
      const salt = await bcrypt.genSaltSync(10);
      const hash = await bcrypt.hashSync(newPassword, salt);
      let newSql = "UPDATE users SET password = ? WHERE id = ?";
      db.query(newSql, [hash, result[0].id], async (error, result) => {
        if (!result) {
          return res.status(401).json({
            message: "The user is not found",
          });
        }
        return res.json({
          message: "Password Changed Successfully",
        });
      });
    }
  });
};

exports.changeEmail = (req, res, next) => {
  const { email, newEmail } = req.body;
  let sql = "SELECT * FROM users WHERE email = ?";

  db.query(sql, [email], async (error, result) => {
    if (result.length == 0) {
      return res.status(401).json({
        message: "The email is not registered",
      });
    }
    if (!result) {
      return res.status(401).json({
        message: "The user is not found",
      });
    } else {
      let newSql = "UPDATE users SET email = ? WHERE id = ?";
      db.query(newSql, [newEmail, result[0].id], async (error, result) => {
        if (!result) {
          return res.status(401).json({
            message: "Database operation error",
          });
        }
        return res.json({
          message: "Email Changed Successfully",
        });
      });
    }
  });
};
exports.changeUsername = (req, res, next) => {
  const { newUsername, username } = req.body;
  let sql = "SELECT * FROM users WHERE username = ?";

  db.query(sql, [username], async (error, result) => {
    if (result.length == 0) {
      return res.status(401).json({
        message: "The username is not registered",
      });
    }
    if (!result) {
      return res.status(401).json({
        message: "The user is not found",
      });
    } else {
      let newSql = "UPDATE users SET username = ? WHERE id = ?";
      db.query(newSql, [newUsername, result[0].id], async (error, result) => {
        if (!result) {
          return res.status(401).json({
            message: "Database operation error",
          });
        }
        return res.json({
          message: "Username Changed Successfully",
        });
      });
    }
  });
};

exports.updateUserFullname = (req, res, next) => {
  const { fullName } = req.body;

  let profileSql = "UPDATE users SET name = ? WHERE id = ?";
  db.query(profileSql, [fullName, req.userId], async (error, result) => {
    if (!result) {
      return res.status(401).json({
        message: "Database operation error",
      });
    }
    res.send({ success: true });
  });
};

exports.updateProfilePicture = (req, res, next) => {
  const profilePicture = req.files[0].filename;

  let profileSql = "UPDATE users SET profile = ? WHERE id = ?";
  db.query(profileSql, [profilePicture, req.userId], async (error, result) => {
    if (!result) {
      return res.status(401).json({
        message: "Database operation error",
      });
    }
    res.send({ success: true });
  });
};

exports.getMe = (req, res, next) => {
  let sql = "SELECT * FROM users WHERE id = ?";

  db.query(sql, [req.userId], async (error, result) => {
    if (error) {
      return res.status(401).json({
        message: "Database operation error",
        user: null,
      });
    }
    if (!result) {
      return res.status(401).json({
        message: "The user is not found",
        user: null,
      });
    }

    //! strictly delete pass field for client side
    var user = result[0];
    delete user.password;

    return res.status(200).json({
      message: "The user is found",
      user: user,
    });
  });
};

exports.logout = (req, res, next) => {
  return res.status(200).json({
    message: "The user has logged out",
    user: null,
  });
};

exports.forgotPassword = (req, res, next) => {
  let sql = "SELECT * FROM users WHERE email = ?";
  const { email } = req.body;

  db.query(sql, [email], async (error, result) => {
    if (result.length == 0) {
      return res.status(401).json({
        message: "The email is not registered",
      });
    }
    if (error) {
      console.log(error);
      return res.status(400).json({
        message: "Database operation failed",
      });
    } else {
      const secret = process.env.JWT_SECRET + result[0].password;
      const payload = {
        email: result[0].email,
        id: result[0].id,
      };
      const token = jwt.sign(payload, secret, {
        expiresIn: "15m",
      });

      // const link = `https://bishant.nepalthamisociety.org/reset-password/${result[0].id}/${token}`
      const link = `http://localhost:3000/reset-password/${result[0].id}/${token}`;
      console.log(link);
      const options = {
        subject: "Reset password",
        html: `<div>
                        <p>Your Password reset Link is</p>
                         <a href='${link}'>${link}</a>
                        </div>`,
        // text: link,
        email: email,
      };
      try {
        const dmail = await sendEmail(options);

        return res.status(200).json({
          message: "The email was send to your address",
        });
      } catch (error) {
        return res.status(400).json({
          message: "The email was not send",
        });
      }
    }
  });
};

exports.resetPassword = (req, res, next) => {
  const { password, confirm, id, token } = req.body;
  console.log(id);
  if (password !== confirm) {
    return res.status(400).json({ message: "The password do not match" });
  }
  let sql = "SELECT * FROM users WHERE id = ?";

  db.query(sql, [id], async (error, result) => {
    if (!result) {
      return res.status(401).json({ message: "The link is not valid" });
    }
    if (error) {
      console.log(error);
      return res.status(401).json({ message: "Database operation failed" });
    } else {
      let email = result[0].email;

      console.log(result[0]);
      const secret = process.env.JWT_SECRET + result[0].password;
      try {
        const payload = jwt.verify(token, secret);
        if (!payload) {
          return res.status(400).json({ message: "The link is not valid" });
        }
        const salt = await bcrypt.genSaltSync(10);
        const hash = await bcrypt.hashSync(password, salt);
        let newSql = "UPDATE users SET password = ? WHERE id = ?";

        db.query(newSql, [hash, id], async (error, result) => {
          if (error) {
            console.log(error);
            return res
              .status(401)
              .json({ message: "Database operation failed" });
          }
          console.log(result);
          if (!result) {
            return res
              .status(401)
              .json({ message: "Database operation failed" });
          }
          const options = {
            subject: "Reset password",
            html: `<div>
                                        <p>Your Password has been reset</p>
                                        </div>`,
            // text: link,
            email: email,
          };
          const dmail = await sendEmail(options);
          return res.status(200).json({
            message: "password updated",
          });
        });
      } catch (error) {
        return res.status(400).json({ message: "The link is not valid" });
      }
    }
  });
};
