const { db } = require("../utils/db");
const path = require("path");

exports.createFundRaiser = (req, res, next) => {
  const {
    title,
    image,
    detail,
    projected,
    start,
    end,
    days,
    raised,
    category,
    rank,
  } = req.body;
  let sql = `INSERT INTO fundraiser SET ?`;
  let data = {
    title: title,
    detail: detail,
    projected: projected,
    start: start,
    end: end,
    days: days,
    raised: raised,
    category: category,
    image: image,
    rank: rank,
  };
  db.query(sql, data, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Fundraiser created",
    });
  });
};
exports.updateFundRaiser = (req, res, next) => {
  const {
    title,
    image,
    detail,
    projected,
    start,
    end,
    days,
    raised,
    category,
    rank,
    id,
  } = req.body;
  const sql = `UPDATE fundraiser SET title = ?,detail = ?,projected = ?, start = ?, end = ?,days = ?,raised = ?,category = ?, image = ?, rank = ? WHERE id = ?`;

  db.query(
    sql,
    [
      title,
      detail,
      projected,
      start,
      end,
      days,
      raised,
      category,
      image,
      rank,
      id,
    ],
    (error, result) => {
      if (error) {
        console.log(error);
        return res.status(401).json({
          message: "Database operation failed",
        });
      }
      return res.status(200).json({
        message: "Fund Raiser updated",
      });
    }
  );
};
exports.deleteFundRaiser = (req, res, next) => {
  const { id } = req.body;
  const sql = `DELETE FROM fundraiser WHERE id = '${id}'`;

  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Fund Raiser deleted",
    });
  });
};
exports.getFundRaiser = (req, res, next) => {
  let sql = `SELECT * FROM fundraiser`;
  db.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      return res.status(401).json({
        message: "Database operation failed",
      });
    }
    return res.status(200).json({
      message: "Fund Raiser fetched",
      data: result,
      // data: result[0]
    });
  });
};
