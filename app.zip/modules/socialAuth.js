const axios = require("axios");
const dotenv = require("dotenv");
const getDeviceName = require("../utils/device");
const { db } = require("../utils/db");

const jwt = require("jsonwebtoken");
const { OAuth2Client } = require("google-auth-library");

dotenv.config({ path: "./utils/.env" });

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
// const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const googleClient = new OAuth2Client(
  GOOGLE_CLIENT_ID
  // GOOGLE_CLIENT_SECRET
);

exports.loginWithFacebook = async (req, res, next) => {
  const { token, countryCode } = req.body;
  const fields = "id,name,picture";
  const userLoginRes = await axios.get(
    `https://graph.facebook.com/v17.0/me?fields=${fields}&access_token=${token}`
  );

  const { id, name } = userLoginRes.data;
  const socialProfile = userLoginRes.data?.picture?.data?.url || "";

  let sql = "SELECT * FROM users WHERE socialID = ?";

  try {
    db.query(sql, [id], async (error, result) => {
      if (error) {
        res.status(400).json({ message: "Failed to login" });
      }
      if (result.length == 0) {
        // create new account if not exits
        let registerSql = "INSERT INTO users SET ?";

        // user device type;
        const device = getDeviceName(req.headers["user-agent"]);

        const data = {
          name,
          socialID: id,
          socialProfile,
          socialSource: "Facebook",
          role: "user",
          device,
          countryCode,
          emailVerified: 1,
        };

        db.query(registerSql, data, async (error, result) => {
          if (error) throw new Error("Failed to login");

          loginUserBySocialID(id, res);
        });
      } else {
        completeLogin(result[0], res);
      }
    });
  } catch (error) {
    return res.status(400).json({ message: "Failed to login!" });
  }
};

exports.loginWithGoogle = async (req, res, next) => {
  const { token, countryCode } = req.body;
  // const { tokens } = await googleClient.getToken(code);
  // const accessToken = tokens.access_token;

  // Verify the Google ID token
  const ticket = await googleClient.verifyIdToken({
    idToken: token,
    audience: GOOGLE_CLIENT_ID,
  });

  const payload = ticket.getPayload();

  // extract user data from the payload as needed
  const userId = payload.sub;
  const email = payload.email;
  const name = payload.name;

  const socialProfile = payload.picture || "";

  let sql = "SELECT * FROM users WHERE socialID = ?";

  try {
    db.query(sql, [userId], async (error, result) => {
      if (error) {
        res.status(400).json({ message: "Failed to login" });
      }
      if (result.length == 0) {
        // create new account if not exits
        let registerSql = "INSERT INTO users SET ?";

        // user device type;
        const device = getDeviceName(req.headers["user-agent"]);

        const data = {
          name,
          email,
          socialID: userId,
          socialProfile,
          socialSource: "Google",
          role: "user",
          device,
          countryCode,
          emailVerified: 1,
        };

        db.query(registerSql, data, async (error, result) => {
          if (error) throw new Error("Failed to login");

          loginUserBySocialID(userId, res);
        });
      } else {
        completeLogin(result[0], res);
      }
    });
  } catch (error) {
    return res.status(400).json({ message: "Failed to login!" });
  }
};

const loginUserBySocialID = async (socialID, res) => {
  let sql = "SELECT * FROM users WHERE socialID = ?";

  db.query(sql, [socialID], async (error, result) => {
    if (error || result.length == 0) {
      return res.status(400).json({ message: "Failed to login" });
    }
    completeLogin(result[0], res);
  });
};

const completeLogin = (data, res) => {
  const id = data.id;
  const token = jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: 21600,
  });

  const user = { ...data };
  delete user?.password;
  delete user?.verificationCode;

  res.json({ message: "Login Successfull", user, token: token });
};
